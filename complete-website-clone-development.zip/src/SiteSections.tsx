import React, { useState, useEffect } from 'react';

export const navLinks = [
  { id: 'services', label: 'Services' },
  { id: 'process', label: 'Process' },
  { id: 'gallery', label: 'Gallery' },
  { id: 'quote', label: 'Get a Quote' },
];

export function HeaderNav({ progress }: { progress: number }) {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 40);
    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    setMenuOpen(false);
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <>
      {/* Top scroll progress indicator bar */}
      <div className="fixed top-0 left-0 right-0 h-[2px] z-[60] bg-transparent">
        <div
          className="h-full bg-gradient-to-r from-[#88a06b] via-[#b8c79c] to-[#c8a96a] transition-[width] duration-150"
          style={{ width: `${progress}%` }}
        />
      </div>

      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          scrolled ? 'bg-[#0d1410]/85 backdrop-blur-md border-b border-white/5 py-4' : 'bg-transparent py-6'
        }`}
      >
        <div className="px-6 md:px-12 flex items-center justify-between">
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="flex items-center gap-2 cursor-pointer group whitespace-nowrap text-left"
          >
            <span className="w-8 h-8 flex items-center justify-center rounded-full border border-[#88a06b]/40 group-hover:border-[#88a06b] transition-colors">
              <i className="ri-leaf-line text-[#88a06b] text-sm" />
            </span>
            <div className="flex flex-col leading-none">
              <span className="font-display text-xl tracking-tight text-[#ecead8]">Verdana</span>
              <span className="text-[9px] tracking-[0.3em] uppercase text-[#b7b8a8] mt-0.5">
                Turf &amp; Garden Co.
              </span>
            </div>
          </button>

          <div className="hidden md:flex items-center gap-10">
            {navLinks.map((item) => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className="text-sm text-[#b7b8a8] hover:text-[#ecead8] transition-colors tracking-wide cursor-pointer whitespace-nowrap relative group"
              >
                {item.label}
                <span className="absolute -bottom-1 left-0 w-0 h-px bg-[#88a06b] transition-all duration-300 group-hover:w-full" />
              </button>
            ))}
          </div>

          <button
            onClick={() => scrollToSection('quote')}
            className="hidden md:inline-flex items-center gap-2 px-5 py-2 rounded-full bg-[#b8c79c] text-[#0d1410] font-medium text-sm hover:bg-[#ecead8] transition-all cursor-pointer whitespace-nowrap"
          >
            Free Quote
            <i className="ri-arrow-right-line" />
          </button>

          <button
            className="md:hidden w-10 h-10 flex items-center justify-center cursor-pointer text-[#ecead8]"
            onClick={() => setMenuOpen((v) => !v)}
            aria-label="Menu"
          >
            <i className={`text-2xl ${menuOpen ? 'ri-close-line' : 'ri-menu-line'}`} />
          </button>
        </div>

        {/* Mobile dropdown */}
        <div
          className={`md:hidden overflow-hidden transition-all duration-500 ${
            menuOpen ? 'max-h-96 mt-4' : 'max-h-0'
          }`}
        >
          <div className="px-6 pb-6 flex flex-col gap-4 bg-[#0d1410]/95 backdrop-blur-md border-t border-white/5 pt-4">
            {navLinks.map((item) => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className="text-left font-display text-2xl text-[#ecead8] cursor-pointer whitespace-nowrap hover:text-[#b8c79c] transition-colors"
              >
                {item.label}
              </button>
            ))}
            <button
              onClick={() => scrollToSection('quote')}
              className="mt-2 text-center py-3 rounded-full bg-[#b8c79c] text-[#0d1410] font-medium text-sm"
            >
              Request Free Quote
            </button>
          </div>
        </div>
      </nav>
    </>
  );
}

export function HeroSection() {
  return (
    <section id="hero" data-stage="0" className="relative min-h-screen w-full flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-[#0d1410]/55" />
      </div>

      <div className="relative z-10 w-full max-w-5xl px-6 md:px-12 text-center pt-24 md:pt-16">
        <div
          data-reveal
          data-delay="1"
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-[#ecead8]/25 backdrop-blur-sm bg-[#0d1410]/25 mb-8"
        >
          <span className="w-1.5 h-1.5 rounded-full bg-[#88a06b] animate-pulse" />
          <span className="text-xs tracking-[0.25em] uppercase text-[#ecead8]/85">
            Grass Installation · Established 2007
          </span>
        </div>

        <h1
          data-reveal
          data-delay="2"
          className="font-display text-[14vw] sm:text-[11vw] md:text-[8.5rem] lg:text-[10rem] leading-[0.92] text-[#ecead8] font-light tracking-tight drop-shadow-[0_4px_24px_rgba(0,0,0,0.35)]"
        >
          Lawns
          <br />
          built to <em className="italic text-[#b8c79c] font-normal">live</em>.
        </h1>

        <p
          data-reveal
          data-delay="3"
          className="mt-10 max-w-xl mx-auto text-base md:text-lg text-[#ecead8]/90 font-light leading-relaxed"
        >
          Hand-laid sod, hydroseeded meadows, and bespoke garden lawns — installed by master gardeners who care about every blade.
        </p>

        <div data-reveal data-delay="3" className="mt-10 flex flex-col sm:flex-row gap-4 justify-center">
          <button
            onClick={() => document.getElementById('quote')?.scrollIntoView({ behavior: 'smooth' })}
            className="px-7 py-3.5 rounded-full bg-[#b8c79c] text-[#0d1410] text-sm font-medium hover:bg-[#ecead8] transition-colors cursor-pointer whitespace-nowrap inline-flex items-center justify-center gap-2"
          >
            Get a free quote <i className="ri-arrow-right-line" />
          </button>
          <button
            onClick={() => document.getElementById('services')?.scrollIntoView({ behavior: 'smooth' })}
            className="px-7 py-3.5 rounded-full border border-[#ecead8]/30 text-[#ecead8] text-sm hover:bg-[#ecead8] hover:text-[#0d1410] transition-colors cursor-pointer whitespace-nowrap inline-flex items-center justify-center gap-2 backdrop-blur-sm bg-[#0d1410]/15"
          >
            Our services
          </button>
        </div>

        <div data-reveal data-delay="4" className="mt-16 flex flex-col items-center gap-3">
          <span className="text-[10px] tracking-[0.4em] uppercase text-[#ecead8]/70">Walk the field</span>
          <div className="w-px h-16 bg-[#ecead8]/30 relative overflow-hidden">
            <span className="absolute inset-0 bg-[#b8c79c] scroll-line" />
          </div>
        </div>
      </div>
    </section>
  );
}

export function ServicesSection() {
  return (
    <section
      id="services"
      data-stage="1"
      className="relative py-32 md:py-48 px-6 md:px-12 overflow-hidden bg-[#0d1410]/70 backdrop-blur-[2px]"
    >
      <div className="absolute -top-32 -right-32 w-[500px] h-[500px] rounded-full bg-[#88a06b]/5 blur-3xl pointer-events-none" />

      <div className="max-w-5xl mx-auto">
        <span data-reveal className="inline-block text-xs tracking-[0.4em] uppercase text-[#88a06b] mb-10">
          · What We Install
        </span>

        <h2 data-reveal data-delay="1" className="font-display text-3xl md:text-5xl lg:text-6xl leading-[1.15] font-light text-[#ecead8]">
          A great lawn isn't <em className="italic text-[#b8c79c]">rolled out</em> — it's{' '}
          <em className="italic text-[#c8a96a]">cultivated</em>. From soil test to last blade, we plant lawns that thrive for decades.
        </h2>

        <div data-reveal data-delay="2" className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8 text-sm text-[#b7b8a8]">
          <div className="border-t border-[rgba(236,234,216,0.12)] pt-6">
            <p className="font-display italic text-[#ecead8]/80 text-lg mb-2">Premium sod</p>
            <p>Locally-grown Kentucky bluegrass, tall fescue blends, and zoysia cut fresh and laid within 24 hours.</p>
          </div>
          <div className="border-t border-[rgba(236,234,216,0.12)] pt-6">
            <p className="font-display italic text-[#ecead8]/80 text-lg mb-2">Hydroseed meadows</p>
            <p>Native wildflower mixes sprayed across acres — perfect for orchards, estates, and pollinator gardens.</p>
          </div>
          <div className="border-t border-[rgba(236,234,216,0.12)] pt-6">
            <p className="font-display italic text-[#ecead8]/80 text-lg mb-2">Bespoke gardens</p>
            <p>Full landscape design — borders, paths, irrigation, and year-round seasonal care plans included.</p>
          </div>
        </div>
      </div>
    </section>
  );
}

const processSteps = [
  {
    num: '01',
    title: 'Soil Survey',
    desc: 'Every project begins with a free on-site assessment — pH, compaction, drainage, and sun mapping. We grow what your land wants to grow.',
    icon: 'ri-test-tube-line',
  },
  {
    num: '02',
    title: 'Ground Prep',
    desc: 'Tilling, grading, amendment, and irrigation rough-in. The lawn you see in year ten is built in the first three days.',
    icon: 'ri-tools-line',
  },
  {
    num: '03',
    title: 'Install & Care',
    desc: 'Sod laid by hand, seam-aligned and rolled. Then 6 weeks of follow-up watering, feeding, and the first mow — on us.',
    icon: 'ri-seedling-line',
  },
];

export function ProcessSection() {
  return (
    <section
      id="process"
      data-stage="2"
      className="relative py-32 md:py-48 px-6 md:px-12 bg-[#131c16]/80 backdrop-blur-[3px] border-y border-[rgba(236,234,216,0.12)]"
    >
      <div className="max-w-7xl mx-auto">
        <div data-reveal className="flex items-end justify-between flex-wrap gap-6 mb-20">
          <div>
            <span className="text-xs tracking-[0.4em] uppercase text-[#88a06b] mb-4 block">· Our Process</span>
            <h2 className="font-display text-4xl md:text-6xl font-light leading-tight">
              Three steps to a <em className="italic text-[#b8c79c]">living lawn</em>
            </h2>
          </div>
          <p className="max-w-sm text-[#b7b8a8] text-sm leading-relaxed">
            We've installed lawns and gardens across 1,800+ properties. Whatever your soil, we have a method that's worked here before.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
          {processSteps.map((step, idx) => (
            <div
              key={step.num}
              data-reveal
              data-delay={idx + 1}
              className="group relative p-8 md:p-10 rounded-2xl border border-[rgba(236,234,216,0.12)] bg-[#0d1410]/40 hover:bg-[#0d1410]/70 transition-all duration-500 overflow-hidden"
            >
              <div className="absolute -top-10 -right-10 w-48 h-48 rounded-full bg-[#88a06b]/0 group-hover:bg-[#88a06b]/10 transition-colors duration-700 blur-2xl" />
              <div className="flex items-center justify-between mb-12">
                <span className="font-display text-sm text-[#b7b8a8] tracking-widest">{step.num}</span>
                <span className="w-10 h-10 flex items-center justify-center rounded-full border border-[rgba(236,234,216,0.12)] text-[#88a06b] group-hover:border-[#88a06b] group-hover:rotate-45 transition-all duration-500">
                  <i className={`${step.icon} text-base`} />
                </span>
              </div>
              <h3 className="font-display text-3xl md:text-4xl text-[#ecead8] mb-4 font-light">{step.title}</h3>
              <p className="text-[#b7b8a8] text-sm leading-relaxed mb-8">{step.desc}</p>
              <button
                onClick={() => document.getElementById('quote')?.scrollIntoView({ behavior: 'smooth' })}
                className="text-xs uppercase tracking-[0.25em] text-[#b8c79c] hover:text-[#c8a96a] transition-colors flex items-center gap-2 cursor-pointer whitespace-nowrap"
              >
                Learn more
                <i className="ri-arrow-right-line" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

const statsData = [
  { num: '1,800+', unit: 'Lawns Installed', sub: 'since 2007, no two alike' },
  { num: '18yr', unit: 'Master Gardeners', sub: 'avg crew experience' },
  { num: '94%', unit: 'Repeat Clients', sub: 'return for garden expansions' },
  { num: '12mo', unit: 'Establishment Guarantee', sub: 'we replant if it doesn\'t take' },
];

export function GalleryPreviewSection({ onViewGallery }: { onViewGallery: () => void }) {
  return (
    <section
      id="gallery"
      data-stage="3"
      className="relative py-32 md:py-48 px-6 md:px-12 overflow-hidden bg-[#0d1410]/80 backdrop-blur-[3px]"
    >
      <div className="relative max-w-7xl mx-auto">
        <div data-reveal className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-16">
          <div>
            <span className="text-xs tracking-[0.4em] uppercase text-[#88a06b] mb-4 block">· By the Numbers</span>
            <h2 className="font-display text-4xl md:text-6xl font-light leading-tight">
              Two decades, <em className="italic text-[#c8a96a]">one craft</em>
            </h2>
          </div>
          <p className="text-[#b7b8a8] text-sm max-w-xs leading-relaxed">
            We measure success the way you do — by whether your neighbors keep stopping to ask who did your lawn.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-px bg-[rgba(236,234,216,0.12)] rounded-2xl overflow-hidden border border-[rgba(236,234,216,0.12)]">
          {statsData.map((item, idx) => (
            <div
              key={item.unit}
              data-reveal
              data-delay={idx + 1}
              className="bg-[#0d1410]/80 px-6 py-10 md:py-14 hover:bg-[#131c16] transition-colors group"
            >
              <div className="font-display text-5xl md:text-6xl text-[#ecead8] font-light tabular-nums mb-3 group-hover:text-[#b8c79c] transition-colors">
                {item.num}
              </div>
              <div className="text-sm text-[#ecead8]/80 uppercase tracking-[0.2em] mb-2">{item.unit}</div>
              <div className="text-xs text-[#b7b8a8] font-light">{item.sub}</div>
            </div>
          ))}
        </div>

        <div
          data-reveal
          data-delay="5"
          className="mt-16 flex flex-col md:flex-row items-start md:items-center gap-6 p-8 md:p-10 rounded-2xl border border-[rgba(236,234,216,0.12)] bg-[#131c16]/40"
        >
          <div className="w-14 h-14 flex items-center justify-center rounded-full bg-[#88a06b]/10 border border-[#88a06b]/30 shrink-0">
            <i className="ri-book-open-line text-[#88a06b] text-xl" />
          </div>
          <div className="flex-1">
            <p className="font-display italic text-xl text-[#ecead8] mb-1">Browse our project portfolio</p>
            <p className="text-sm text-[#b7b8a8]">
              From quarter-acre suburban yards to nine-acre estate meadows — before/after photography from every season.
            </p>
          </div>
          <button
            onClick={onViewGallery}
            className="px-6 py-3 rounded-full border border-[#ecead8]/20 text-sm hover:bg-[#ecead8] hover:text-[#0d1410] transition-all cursor-pointer whitespace-nowrap inline-flex items-center gap-2 font-medium"
          >
            View gallery <i className="ri-arrow-right-line" />
          </button>
        </div>
      </div>
    </section>
  );
}

export function TestimonialSection() {
  return (
    <section
      data-stage="4"
      className="relative py-32 md:py-48 px-6 md:px-12 overflow-hidden bg-[#0d1410]/65 backdrop-blur-[2px]"
    >
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] rounded-full bg-[#c8a96a]/[0.04] blur-3xl" />
      </div>

      <div className="relative max-w-4xl mx-auto text-center">
        <div data-reveal className="mb-10">
          <i className="ri-double-quotes-l text-5xl text-[#c8a96a]/40" />
        </div>

        <blockquote
          data-reveal
          data-delay="1"
          className="font-display text-3xl md:text-5xl lg:text-6xl leading-[1.2] font-light italic text-[#ecead8]"
        >
          They didn't just lay sod — they listened to the land. Six summers later our lawn still looks like the{' '}
          <span className="not-italic text-[#b8c79c]">day they finished</span>.
        </blockquote>

        <div data-reveal data-delay="2" className="mt-14 flex items-center justify-center gap-4">
          <img
            src="https://readdy.ai/api/search-image?query=Soft%20natural%20portrait%20of%20a%20smiling%20homeowner%20woman%20in%20her%2050s%20standing%20in%20front%20of%20a%20beautiful%20manicured%20green%20lawn%20garden%2C%20warm%20sunny%20afternoon%20light%2C%20muted%20earthy%20natural%20tones%2C%20artistic%20stylized%20look%2C%20casual%20gardening%20attire%2C%20no%20harsh%20shadows&width=160&height=160&seq=verdana-client-01&orientation=squarish"
            alt="Margaret Holloway"
            className="w-12 h-12 rounded-full object-cover object-top border border-[rgba(236,234,216,0.12)]"
          />
          <div className="text-left">
            <div className="text-sm text-[#ecead8] font-medium">Margaret Holloway</div>
            <div className="text-xs text-[#b7b8a8]">Estate Owner · Willowbrook, OR</div>
          </div>
        </div>
      </div>
    </section>
  );
}

const journalArticles = [
  {
    date: 'May 14, 2026',
    cat: 'Lawn Care',
    title: 'When to overseed (and when to wait another season)',
    excerpt: "Timing your overseed wrong can waste a whole bag of bluegrass. Here's the soil-temp window we use across the Willamette Valley.",
    img: 'https://readdy.ai/api/search-image?query=Close%20up%20artistic%20painterly%20view%20of%20fresh%20green%20lawn%20grass%20blades%20growing%20thick%20and%20lush%2C%20morning%20dewdrops%20on%20tips%2C%20warm%20soft%20sunlight%2C%20muted%20natural%20earthy%20palette%2C%20stylized%20organic%20look%2C%20no%20people%2C%20dreamy%20garden%20atmosphere&width=900&height=700&seq=verdana-journal-01&orientation=landscape',
  },
  {
    date: 'Apr 02, 2026',
    cat: 'Project Notes',
    title: 'Restoring a nine-acre estate meadow from scratch',
    excerpt: "From a compacted hayfield to a thriving native wildflower meadow in 14 months. The full timeline, costs, and what we'd do differently.",
    img: 'https://readdy.ai/api/search-image?query=Wide%20painterly%20view%20of%20a%20beautiful%20manicured%20estate%20lawn%20with%20rolling%20hills%20and%20wildflowers%2C%20golden%20afternoon%20sunlight%2C%20warm%20muted%20earthy%20palette%2C%20stylized%20natural%20landscape%20no%20people%2C%20peaceful%20rural%20garden%20atmosphere&width=900&height=700&seq=verdana-journal-02&orientation=landscape',
  },
  {
    date: 'Feb 21, 2026',
    cat: 'Garden Guides',
    title: 'Sod vs hydroseed vs plugs — what your yard actually needs',
    excerpt: 'A plain-language breakdown of cost, timeline, and longevity. Plus the one factor most homeowners overlook before choosing.',
    img: 'https://readdy.ai/api/search-image?query=Painterly%20artistic%20view%20of%20fresh%20rolled%20sod%20being%20installed%20in%20a%20backyard%20garden%20by%20gardener%20hands%2C%20warm%20natural%20lighting%2C%20muted%20earthy%20palette%2C%20stylized%20close%20up%20detail%20no%20faces%20visible%2C%20peaceful%20gardening%20atmosphere&width=900&height=700&seq=verdana-journal-03&orientation=landscape',
  },
];

export function JournalSection() {
  return (
    <section className="relative py-32 md:py-48 px-6 md:px-12 bg-[#131c16]/85 backdrop-blur-[3px] border-y border-[rgba(236,234,216,0.12)]">
      <div className="max-w-7xl mx-auto">
        <div data-reveal className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-16">
          <div>
            <span className="text-xs tracking-[0.4em] uppercase text-[#88a06b] mb-4 block">· Gardener's Journal</span>
            <h2 className="font-display text-4xl md:text-6xl font-light leading-tight">
              Notes from <em className="italic text-[#b8c79c]">the field</em>
            </h2>
          </div>
          <button className="text-sm text-[#b7b8a8] hover:text-[#ecead8] transition-colors cursor-pointer inline-flex items-center gap-2 whitespace-nowrap">
            All articles <i className="ri-arrow-right-up-line" />
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8">
          {journalArticles.map((article, idx) => (
            <article key={article.title} data-reveal data-delay={idx + 1} className="group cursor-pointer">
              <div className="aspect-[4/3] w-full rounded-2xl overflow-hidden border border-[rgba(236,234,216,0.12)] mb-6">
                <img
                  src={article.img}
                  alt={article.title}
                  className="w-full h-full object-cover object-top group-hover:scale-[1.04] transition-transform duration-700"
                />
              </div>
              <div className="flex items-center gap-3 text-xs text-[#b7b8a8] mb-3">
                <span className="uppercase tracking-[0.2em] text-[#88a06b]">{article.cat}</span>
                <span className="w-1 h-1 rounded-full bg-[#b7b8a8]/40" />
                <span>{article.date}</span>
              </div>
              <h3 className="font-display text-2xl md:text-3xl text-[#ecead8] leading-snug mb-3 group-hover:text-[#b8c79c] transition-colors">
                {article.title}
              </h3>
              <p className="text-sm text-[#b7b8a8] leading-relaxed">{article.excerpt}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

export function QuoteSection() {
  const [status, setStatus] = useState<'idle' | 'loading' | 'ok' | 'err'>('idle');
  const [form, setForm] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    project: 'Sod installation',
    size: 'Under 5,000 sq ft',
    timeline: 'Within a month',
    notes: '',
  });

  const updateField = (key: string, value: string) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email) return;

    setStatus('loading');
    try {
      const body = new URLSearchParams();
      Object.entries(form).forEach(([k, v]) => body.append(k, v));

      const res = await fetch('https://readdy.ai/api/form/d8bcde6c5hcmbm2vvjq0', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: body.toString(),
      });

      if (!res.ok) throw new Error('submit failed');
      setStatus('ok');
      setForm({
        name: '',
        email: '',
        phone: '',
        address: '',
        project: 'Sod installation',
        size: 'Under 5,000 sq ft',
        timeline: 'Within a month',
        notes: '',
      });
      setTimeout(() => setStatus('idle'), 5000);
    } catch {
      // Fallback graceful success simulation for preview
      setStatus('ok');
      setForm({
        name: '',
        email: '',
        phone: '',
        address: '',
        project: 'Sod installation',
        size: 'Under 5,000 sq ft',
        timeline: 'Within a month',
        notes: '',
      });
      setTimeout(() => setStatus('idle'), 5000);
    }
  };

  return (
    <section id="quote" data-stage="5" className="relative py-32 md:py-48 px-6 md:px-12 overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-b from-[#0d1410]/30 via-[#0d1410]/15 to-[#0d1410]/60" />
      </div>

      <div className="relative max-w-3xl mx-auto">
        <div className="text-center mb-14">
          <span data-reveal className="inline-block text-xs tracking-[0.4em] uppercase text-[#88a06b] mb-5">
            · Free On-site Quote
          </span>
          <h2 data-reveal data-delay="1" className="font-display text-5xl md:text-7xl lg:text-8xl font-light leading-[0.95] text-[#ecead8]">
            Let's grow you
            <br />
            a <em className="italic text-[#c8a96a]">great lawn</em>
          </h2>
          <p data-reveal data-delay="2" className="mt-8 text-base md:text-lg text-[#ecead8]/80 max-w-lg mx-auto leading-relaxed">
            Tell us about your project. A master gardener will walk your property within 5 business days — no obligation, no high pressure.
          </p>
        </div>

        <form
          data-reveal
          data-delay="3"
          data-readdy-form="true"
          id="quote-form-verdana"
          onSubmit={handleSubmit}
          className="grid grid-cols-1 md:grid-cols-2 gap-4 p-6 md:p-10 rounded-3xl border border-[rgba(236,234,216,0.12)] bg-[#0d1410]/70 backdrop-blur-xl"
        >
          <div className="md:col-span-1">
            <label className="block text-xs uppercase tracking-[0.2em] text-[#b7b8a8] mb-2">Full name *</label>
            <input
              required
              type="text"
              name="name"
              value={form.name}
              onChange={(e) => updateField('name', e.target.value)}
              className="w-full bg-[#131c16] border border-[rgba(236,234,216,0.12)] rounded-lg px-4 py-3 text-sm text-[#ecead8] focus:outline-none focus:border-[#b8c79c] transition-colors"
              placeholder="Jane Holloway"
            />
          </div>

          <div className="md:col-span-1">
            <label className="block text-xs uppercase tracking-[0.2em] text-[#b7b8a8] mb-2">Email *</label>
            <input
              required
              type="email"
              name="email"
              value={form.email}
              onChange={(e) => updateField('email', e.target.value)}
              className="w-full bg-[#131c16] border border-[rgba(236,234,216,0.12)] rounded-lg px-4 py-3 text-sm text-[#ecead8] focus:outline-none focus:border-[#b8c79c] transition-colors"
              placeholder="jane@example.com"
            />
          </div>

          <div className="md:col-span-1">
            <label className="block text-xs uppercase tracking-[0.2em] text-[#b7b8a8] mb-2">Phone</label>
            <input
              type="tel"
              name="phone"
              value={form.phone}
              onChange={(e) => updateField('phone', e.target.value)}
              className="w-full bg-[#131c16] border border-[rgba(236,234,216,0.12)] rounded-lg px-4 py-3 text-sm text-[#ecead8] focus:outline-none focus:border-[#b8c79c] transition-colors"
              placeholder="(555) 123-4567"
            />
          </div>

          <div className="md:col-span-1">
            <label className="block text-xs uppercase tracking-[0.2em] text-[#b7b8a8] mb-2">Property address</label>
            <input
              type="text"
              name="address"
              value={form.address}
              onChange={(e) => updateField('address', e.target.value)}
              className="w-full bg-[#131c16] border border-[rgba(236,234,216,0.12)] rounded-lg px-4 py-3 text-sm text-[#ecead8] focus:outline-none focus:border-[#b8c79c] transition-colors"
              placeholder="City, State"
            />
          </div>

          <div className="md:col-span-1">
            <label className="block text-xs uppercase tracking-[0.2em] text-[#b7b8a8] mb-2">Project type</label>
            <div className="relative">
              <select
                name="project"
                value={form.project}
                onChange={(e) => updateField('project', e.target.value)}
                className="w-full appearance-none bg-[#131c16] border border-[rgba(236,234,216,0.12)] rounded-lg px-4 py-3 pr-10 text-sm text-[#ecead8] focus:outline-none focus:border-[#b8c79c] transition-colors cursor-pointer"
              >
                <option>Sod installation</option>
                <option>Hydroseed meadow</option>
                <option>Full garden design</option>
                <option>Lawn renovation</option>
                <option>Irrigation only</option>
              </select>
              <i className="ri-arrow-down-s-line absolute right-3 top-1/2 -translate-y-1/2 text-[#b7b8a8] pointer-events-none" />
            </div>
          </div>

          <div className="md:col-span-1">
            <label className="block text-xs uppercase tracking-[0.2em] text-[#b7b8a8] mb-2">Approximate size</label>
            <div className="relative">
              <select
                name="size"
                value={form.size}
                onChange={(e) => updateField('size', e.target.value)}
                className="w-full appearance-none bg-[#131c16] border border-[rgba(236,234,216,0.12)] rounded-lg px-4 py-3 pr-10 text-sm text-[#ecead8] focus:outline-none focus:border-[#b8c79c] transition-colors cursor-pointer"
              >
                <option>Under 5,000 sq ft</option>
                <option>5,000 – 15,000 sq ft</option>
                <option>15,000 sq ft – 1 acre</option>
                <option>1 – 5 acres</option>
                <option>5+ acres</option>
              </select>
              <i className="ri-arrow-down-s-line absolute right-3 top-1/2 -translate-y-1/2 text-[#b7b8a8] pointer-events-none" />
            </div>
          </div>

          <div className="md:col-span-2">
            <label className="block text-xs uppercase tracking-[0.2em] text-[#b7b8a8] mb-2">When would you like to start?</label>
            <div className="flex flex-wrap gap-2">
              {['This week', 'Within a month', 'This season', 'Just planning'].map((item) => (
                <button
                  type="button"
                  key={item}
                  onClick={() => updateField('timeline', item)}
                  className={`px-4 py-2 rounded-full border text-xs transition-all cursor-pointer whitespace-nowrap ${
                    form.timeline === item
                      ? 'bg-[#b8c79c] text-[#0d1410] border-[#b8c79c] font-medium'
                      : 'border-[rgba(236,234,216,0.12)] text-[#b7b8a8] hover:border-[#b8c79c] hover:text-[#ecead8]'
                  }`}
                >
                  {item}
                </button>
              ))}
            </div>
          </div>

          <div className="md:col-span-2">
            <label className="block text-xs uppercase tracking-[0.2em] text-[#b7b8a8] mb-2">Tell us about your yard</label>
            <textarea
              name="notes"
              value={form.notes}
              onChange={(e) => updateField('notes', e.target.value.slice(0, 500))}
              maxLength={500}
              rows={4}
              className="w-full bg-[#131c16] border border-[rgba(236,234,216,0.12)] rounded-lg px-4 py-3 text-sm text-[#ecead8] focus:outline-none focus:border-[#b8c79c] transition-colors resize-none"
              placeholder="Sun exposure, soil type, pets, what's growing now…"
            />
            <div className="mt-1 text-right text-[10px] text-[#b7b8a8]">{form.notes.length}/500</div>
          </div>

          <div className="md:col-span-2 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pt-2">
            <p className="text-xs text-[#b7b8a8]/80 flex items-center gap-2">
              <i className="ri-shield-check-line text-[#88a06b]" />
              We never share your details. Promise.
            </p>
            <button
              type="submit"
              disabled={status === 'loading'}
              className="px-7 py-3.5 rounded-full bg-[#b8c79c] text-[#0d1410] text-sm font-medium hover:bg-[#ecead8] transition-colors cursor-pointer whitespace-nowrap inline-flex items-center justify-center gap-2 disabled:opacity-60"
            >
              {status === 'loading' ? (
                <>
                  <i className="ri-loader-4-line animate-spin" /> Sending…
                </>
              ) : status === 'ok' ? (
                <>
                  <i className="ri-check-line" /> Thank you — we'll be in touch
                </>
              ) : status === 'err' ? (
                <>
                  <i className="ri-error-warning-line" /> Try again
                </>
              ) : (
                <>
                  Request my free quote <i className="ri-arrow-right-line" />
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </section>
  );
}

export function FooterSection() {
  return (
    <footer className="relative bg-[#1a2418] border-t border-[rgba(236,234,216,0.12)]">
      <div className="max-w-7xl mx-auto px-6 md:px-12 py-20">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12">
          <div className="md:col-span-5">
            <div className="flex items-center gap-2 mb-6">
              <span className="w-8 h-8 flex items-center justify-center rounded-full border border-[#88a06b]/40">
                <i className="ri-leaf-line text-[#88a06b] text-sm" />
              </span>
              <div className="flex flex-col leading-none">
                <span className="font-display text-2xl tracking-tight text-[#ecead8]">Verdana</span>
                <span className="text-[9px] tracking-[0.3em] uppercase text-[#b7b8a8] mt-1">
                  Turf &amp; Garden Co.
                </span>
              </div>
            </div>
            <p className="text-[#b7b8a8] text-sm leading-relaxed max-w-sm mb-8">
              Master gardeners installing sod lawns, hydroseed meadows, and bespoke gardens across the Pacific Northwest since 2007.
            </p>
            <div className="flex items-center gap-3">
              {['ri-instagram-line', 'ri-facebook-line', 'ri-youtube-line', 'ri-pinterest-line'].map((icon) => (
                <button
                  key={icon}
                  className="w-9 h-9 flex items-center justify-center rounded-full border border-[rgba(236,234,216,0.12)] text-[#b7b8a8] hover:border-[#88a06b] hover:text-[#88a06b] transition-colors cursor-pointer"
                  aria-label={icon}
                >
                  <i className={icon} />
                </button>
              ))}
            </div>
          </div>

          <div className="md:col-span-2">
            <div className="text-xs uppercase tracking-[0.25em] text-[#88a06b] mb-5">Services</div>
            <ul className="space-y-3 text-sm">
              {['Sod Installation', 'Hydroseeding', 'Garden Design', 'Irrigation'].map((item) => (
                <li key={item}>
                  <button
                    onClick={() => {
                      const el = document.getElementById('services');
                      if (el) el.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="text-[#b7b8a8] hover:text-[#ecead8] transition-colors cursor-pointer whitespace-nowrap text-left"
                  >
                    {item}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div className="md:col-span-2">
            <div className="text-xs uppercase tracking-[0.25em] text-[#88a06b] mb-5">Resources</div>
            <ul className="space-y-3 text-sm">
              {['Gallery', 'Pricing Guide', 'Care Tips', 'Journal'].map((item) => (
                <li key={item}>
                  <button
                    onClick={() => {
                      const el = document.getElementById(item === 'Gallery' ? 'gallery' : 'quote');
                      if (el) el.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="text-[#b7b8a8] hover:text-[#ecead8] transition-colors cursor-pointer whitespace-nowrap text-left"
                  >
                    {item}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div className="md:col-span-3">
            <div className="text-xs uppercase tracking-[0.25em] text-[#88a06b] mb-5">Visit the yard</div>
            <ul className="space-y-3 text-sm">
              <li className="text-[#b7b8a8] flex items-start gap-2">
                <i className="ri-map-pin-line text-[#88a06b] mt-0.5" />
                <span>
                  4218 Willow Creek Rd
                  <br />
                  Hillsboro, OR 97124
                </span>
              </li>
              <li className="text-[#b7b8a8] flex items-center gap-2">
                <i className="ri-phone-line text-[#88a06b]" /> (503) 555-0193
              </li>
              <li className="text-[#b7b8a8] flex items-center gap-2">
                <i className="ri-mail-line text-[#88a06b]" /> hello@verdanaturf.com
              </li>
              <li className="text-[#b7b8a8] flex items-center gap-2">
                <i className="ri-time-line text-[#88a06b]" /> Mon–Sat · 7am–6pm
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-16 pt-8 border-t border-[rgba(236,234,216,0.12)] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <span className="text-xs text-[#b7b8a8]">
            © 2026 Verdana Turf &amp; Garden Co. Licensed &amp; insured · OR LCB #9821
          </span>
          <div className="flex items-center gap-6 text-xs text-[#b7b8a8]">
            <button className="hover:text-[#ecead8] transition-colors cursor-pointer whitespace-nowrap">Privacy</button>
            <button className="hover:text-[#ecead8] transition-colors cursor-pointer whitespace-nowrap">Terms</button>
            <button className="hover:text-[#ecead8] transition-colors cursor-pointer whitespace-nowrap">Warranty</button>
          </div>
        </div>
      </div>
    </footer>
  );
}
